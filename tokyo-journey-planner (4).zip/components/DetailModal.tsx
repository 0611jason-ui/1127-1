
import React, { useEffect, useState } from 'react';
import { Stop } from '../types';
import { X, Map, Phone, ExternalLink } from 'lucide-react';

interface DetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  stop: Stop | null;
}

export const DetailModal: React.FC<DetailModalProps> = ({ isOpen, onClose, stop }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (isOpen) {
        setIsVisible(true);
    } else {
        const timer = setTimeout(() => setIsVisible(false), 300);
        return () => clearTimeout(timer);
    }
  }, [isOpen]);

  const handleNavigation = () => {
    if (stop?.mapUrl) {
        // Open in a new tab/window (blank page behavior) as requested
        window.open(stop.mapUrl, '_blank');
    }
  };

  if (!isVisible && !isOpen) return null;

  return (
    <div 
        className={`
            fixed inset-0 z-50 flex items-end justify-center sm:items-center
            transition-colors duration-300
            ${isOpen ? 'bg-black/40 backdrop-blur-[2px]' : 'bg-transparent pointer-events-none'}
        `}
        onClick={onClose}
    >
        <div 
            className={`
                bg-white w-full max-w-[420px] rounded-t-3xl sm:rounded-2xl p-6
                transform transition-transform duration-300 ease-out shadow-2xl
                ${isOpen ? 'translate-y-0 sm:scale-100' : 'translate-y-full sm:translate-y-0 sm:scale-95'}
                max-h-[85vh] overflow-y-auto
            `}
            onClick={(e) => e.stopPropagation()}
        >
            {/* Handle Bar for mobile feel */}
            <div className="w-12 h-1.5 bg-gray-200 rounded-full mx-auto mb-6 sm:hidden"></div>

            {stop && (
                <>
                    <div className="flex justify-between items-start mb-6">
                        <div>
                             <span className="inline-block px-2 py-1 bg-blue-600 text-white text-[10px] font-bold rounded-md tracking-wider mb-2">
                                {stop.type}
                            </span>
                            <h2 className="text-2xl font-black text-gray-900 leading-tight">
                                {stop.title}
                            </h2>
                        </div>
                        <button 
                            onClick={onClose}
                            className="p-2 -mr-2 -mt-2 text-gray-400 hover:text-gray-800 rounded-full transition-colors"
                        >
                            <X size={24} />
                        </button>
                    </div>

                    <div className="space-y-6">
                        <div>
                            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 border-b border-gray-100 pb-1">
                                行程細節
                            </h3>
                            <p className="text-gray-700 leading-relaxed text-sm">
                                {stop.details}
                            </p>
                        </div>
                        
                        <div>
                            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2 border-b border-gray-100 pb-1">
                                標籤
                            </h3>
                            <div className="flex flex-wrap gap-2">
                                {stop.tags.map(tag => (
                                    <span key={tag} className="px-3 py-1 bg-gray-100 text-gray-600 text-xs rounded-full font-medium">
                                        #{tag}
                                    </span>
                                ))}
                            </div>
                        </div>

                        <div className="pt-6 border-t border-gray-100 flex justify-around">
                            <ActionButton 
                                icon={<Map size={20} />} 
                                label="導航" 
                                onClick={handleNavigation}
                                disabled={!stop.mapUrl}
                            />
                            {/* Disabled by default as data is not yet available */}
                            <ActionButton icon={<Phone size={20} />} label="聯繫" disabled={true} />
                            <ActionButton icon={<ExternalLink size={20} />} label="網站" disabled={true} />
                        </div>
                    </div>
                </>
            )}
        </div>
    </div>
  );
};

interface ActionButtonProps {
    icon: React.ReactNode;
    label: string;
    onClick?: () => void;
    disabled?: boolean;
}

const ActionButton: React.FC<ActionButtonProps> = ({ icon, label, onClick, disabled }) => {
    return (
        <button 
            className={`flex flex-col items-center transition-all duration-300 ${disabled ? 'opacity-40 cursor-not-allowed grayscale' : 'group cursor-pointer'}`}
            onClick={disabled ? undefined : onClick}
            disabled={disabled}
        >
            <div className={`
                w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-colors duration-300
                ${disabled 
                    ? 'bg-gray-200 text-gray-500' 
                    : 'bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white'
                }
            `}>
                {icon}
            </div>
            <span className={`text-xs font-semibold transition-colors ${disabled ? 'text-gray-400' : 'text-gray-500 group-hover:text-blue-600'}`}>
                {label}
            </span>
        </button>
    );
};
