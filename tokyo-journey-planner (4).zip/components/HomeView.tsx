
import React, { useState, useEffect } from 'react';
import { WeatherWidget } from './WeatherWidget';
import { CalendarDays, TrainFront, Map as MapIcon, ChevronRight, X, ExternalLink, Plane, CheckSquare, Languages } from 'lucide-react';

interface HomeViewProps {
  onNavigate: (view: 'home' | 'itinerary') => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ onNavigate }) => {
  const [showMap, setShowMap] = useState(false);
  const [showTraffic, setShowTraffic] = useState(false);
  const [statusContent, setStatusContent] = useState<React.ReactNode>(null);
  
  // Checklist State
  const [checklist, setChecklist] = useState([
    { id: 1, text: '護照 (效期6個月+)', checked: false },
    { id: 2, text: 'Visit Japan Web', checked: false },
    { id: 3, text: '網卡 / 漫遊', checked: false },
    { id: 4, text: '行動電源 & 轉接頭', checked: false },
    { id: 5, text: '日幣現金', checked: false },
  ]);

  const toggleCheck = (id: number) => {
    setChecklist(prev => prev.map(item => 
        item.id === id ? { ...item, checked: !item.checked } : item
    ));
  };

  // Calculate Status on mount
  useEffect(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const tripYear = 2026;
    const startDate = new Date(tripYear, 0, 11);
    const endDate = new Date(tripYear, 0, 16);

    if (today < startDate) {
        const diffTime = startDate.getTime() - today.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        setStatusContent(
            <>
                距離出發還有 <span className="text-blue-600 font-bold text-lg mx-1">{diffDays}</span> 天
            </>
        );
    } else if (today >= startDate && today <= endDate) {
        setStatusContent(
            <span className="text-green-600 font-bold flex items-center animate-pulse">
                ✈️ 旅遊進行中！Enjoy your trip!
            </span>
        );
    } else {
        setStatusContent(
            <span className="text-gray-400 font-medium">
                旅程已圓滿結束 ✨
            </span>
        );
    }
  }, []);

  return (
    <div className="p-4 space-y-6 pb-24">
        {/* Welcome Header */}
        <div className="mt-4">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Welcome Back</span>
            <h1 className="text-3xl font-black text-gray-800 mt-1">東京之旅 2026 🇯🇵</h1>
            <p className="text-sm text-gray-500 mt-2 flex items-center h-6">
                {statusContent}
            </p>
        </div>

        {/* Weather Section */}
        <WeatherWidget className="w-full" />

        {/* Main Grid Navigation */}
        <div className="grid grid-cols-2 gap-4">
            {/* Itinerary - Main Feature */}
            <button 
                onClick={() => onNavigate('itinerary')}
                className="col-span-2 group relative overflow-hidden bg-white p-6 rounded-3xl shadow-sm border border-gray-100 text-left transition-all hover:shadow-md active:scale-95"
            >
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <CalendarDays size={80} className="text-blue-500" />
                </div>
                <div className="relative z-10">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mb-4 text-blue-600">
                        <CalendarDays size={20} />
                    </div>
                    <h3 className="text-xl font-bold text-gray-800">行程表</h3>
                    <p className="text-sm text-gray-500 mt-1">查看 6 天詳細規劃</p>
                    <div className="mt-4 flex items-center text-blue-600 text-sm font-bold">
                        前往查看 <ChevronRight size={16} />
                    </div>
                </div>
            </button>

            {/* Subway Map */}
            <button 
                onClick={() => setShowMap(true)}
                className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100 text-left transition-all hover:shadow-md active:scale-95"
            >
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mb-3 text-green-600">
                    <MapIcon size={20} />
                </div>
                <h3 className="text-base font-bold text-gray-800">地鐵圖</h3>
                <p className="text-xs text-gray-400 mt-1">Tokyo Metro</p>
            </button>

             {/* Traffic Info */}
             <button 
                onClick={() => setShowTraffic(true)}
                className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100 text-left transition-all hover:shadow-md active:scale-95"
            >
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center mb-3 text-orange-600">
                    <TrainFront size={20} />
                </div>
                <h3 className="text-base font-bold text-gray-800">交通資訊</h3>
                <p className="text-xs text-gray-400 mt-1">Skyliner & Pass</p>
            </button>
        </div>

        {/* 1. Flight Info Card */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-5">
            <div className="flex items-center mb-4">
                <div className="p-2 bg-purple-100 text-purple-600 rounded-full mr-3">
                    <Plane size={18} />
                </div>
                <h3 className="font-bold text-gray-800">航班資訊</h3>
            </div>
            
            <div className="space-y-4">
                {/* Outbound */}
                <div className="flex justify-between items-center border-b border-dashed border-gray-200 pb-3">
                    <div>
                        <span className="text-xs text-gray-400 block mb-1">去程 1/11 (MM620)</span>
                        <div className="flex items-center space-x-2">
                            <div className="text-center">
                                <span className="text-xl font-black text-gray-800 block leading-none">TPE</span>
                                <span className="text-[10px] text-gray-500 font-bold bg-gray-100 px-1 rounded mt-1">T1</span>
                            </div>
                            <span className="text-gray-300 text-xs self-center">✈️</span>
                            <div className="text-center">
                                <span className="text-xl font-black text-gray-800 block leading-none">NRT</span>
                                <span className="text-[10px] text-gray-500 font-bold bg-gray-100 px-1 rounded mt-1">T1</span>
                            </div>
                        </div>
                    </div>
                    <div className="text-right">
                        <span className="text-xs text-gray-400 block mb-1">起飛</span>
                        <span className="text-lg font-bold text-purple-600">02:25</span>
                    </div>
                </div>
                
                {/* Inbound */}
                <div className="flex justify-between items-center">
                    <div>
                        <span className="text-xs text-gray-400 block mb-1">回程 1/16 (IT203)</span>
                         <div className="flex items-center space-x-2">
                            <div className="text-center">
                                <span className="text-xl font-black text-gray-800 block leading-none">NRT</span>
                                <span className="text-[10px] text-gray-500 font-bold bg-gray-100 px-1 rounded mt-1">T2</span>
                            </div>
                            <span className="text-gray-300 text-xs self-center">✈️</span>
                            <div className="text-center">
                                <span className="text-xl font-black text-gray-800 block leading-none">TPE</span>
                                <span className="text-[10px] text-gray-500 font-bold bg-gray-100 px-1 rounded mt-1">T1</span>
                            </div>
                        </div>
                    </div>
                    <div className="text-right">
                        <span className="text-xs text-gray-400 block mb-1">起飛</span>
                        <span className="text-lg font-bold text-purple-600">19:00</span>
                    </div>
                </div>
            </div>
        </div>

        {/* 2. Survival Japanese */}
        <div>
            <div className="flex items-center mb-3 px-1">
                <Languages size={18} className="text-pink-500 mr-2" />
                <h3 className="font-bold text-gray-700">實用日語</h3>
            </div>
            <div className="flex overflow-x-auto gap-3 pb-2 no-scrollbar -mx-4 px-4">
                {[
                    { jp: 'ありがとう', romaji: 'Arigato', zh: '謝謝' },
                    { jp: 'すみません', romaji: 'Sumimasen', zh: '不好意思' },
                    { jp: 'トイレはどこ？', romaji: 'Toire wa doko?', zh: '廁所在哪？' },
                    { jp: 'これください', romaji: 'Kore kudasai', zh: '我要這個' },
                    { jp: 'いくらですか', romaji: 'Ikura desu ka', zh: '多少錢？' },
                ].map((item, idx) => (
                    <div key={idx} className="flex-shrink-0 bg-white p-4 rounded-2xl shadow-sm border border-gray-100 w-36 flex flex-col items-center text-center">
                         <span className="text-lg font-bold text-gray-800 mb-1">{item.jp}</span>
                         <span className="text-xs text-gray-400 mb-2">{item.romaji}</span>
                         <span className="text-sm font-medium text-pink-500">{item.zh}</span>
                    </div>
                ))}
            </div>
        </div>

        {/* 3. Checklist */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-5">
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                    <CheckSquare size={18} className="text-teal-500 mr-2" />
                    <h3 className="font-bold text-gray-800">行前檢查</h3>
                </div>
                <span className="text-xs bg-gray-100 text-gray-500 px-2 py-1 rounded-full">
                    {checklist.filter(i => i.checked).length}/{checklist.length}
                </span>
            </div>
            <div className="space-y-3">
                {checklist.map(item => (
                    <div 
                        key={item.id} 
                        onClick={() => toggleCheck(item.id)}
                        className="flex items-center cursor-pointer group"
                    >
                        <div className={`
                            w-5 h-5 rounded-md border-2 mr-3 flex items-center justify-center transition-colors
                            ${item.checked ? 'bg-teal-500 border-teal-500' : 'border-gray-300 group-hover:border-teal-400'}
                        `}>
                            {item.checked && <CheckSquare size={12} className="text-white" />}
                        </div>
                        <span className={`text-sm transition-colors ${item.checked ? 'text-gray-400 line-through' : 'text-gray-700'}`}>
                            {item.text}
                        </span>
                    </div>
                ))}
            </div>
        </div>

        {/* Modal Logic (Same as before) */}
        {showMap && (
            <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-2 backdrop-blur-sm" onClick={() => setShowMap(false)}>
                <button className="absolute top-4 right-4 text-white p-2">
                    <X size={32} />
                </button>
                <div className="w-full max-h-screen overflow-auto rounded-lg" onClick={(e) => e.stopPropagation()}>
                     <img 
                        src="https://www.tokyometro.jp/en/subwaymap/images/network_en_2020.jpg" 
                        alt="Tokyo Subway Map" 
                        className="w-full h-auto"
                    />
                    <div className="text-center mt-4">
                        <a href="https://www.tokyometro.jp/tcn/subwaymap/" target="_blank" rel="noopener" className="inline-flex items-center text-white underline">
                            查看高畫質原圖 <ExternalLink size={14} className="ml-1" />
                        </a>
                    </div>
                </div>
            </div>
        )}

        {showTraffic && (
            <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center bg-black/40 backdrop-blur-[2px]" onClick={() => setShowTraffic(false)}>
                <div 
                    className="bg-white w-full max-w-[420px] rounded-t-3xl sm:rounded-2xl p-6 animate-slide-up"
                    onClick={(e) => e.stopPropagation()}
                >
                     <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-black text-gray-900">交通快查</h2>
                        <button onClick={() => setShowTraffic(false)} className="p-2 bg-gray-100 rounded-full"><X size={20}/></button>
                    </div>
                    
                    <div className="space-y-4">
                        <div className="p-4 bg-blue-50 rounded-xl">
                            <h3 className="font-bold text-blue-800 mb-1">🚄 京成 Skyliner</h3>
                            <p className="text-sm text-blue-600">成田機場 ↔ 上野/日暮里</p>
                            <p className="text-xs text-blue-500 mt-1">最快 36 分鐘，全車對號座。</p>
                        </div>
                        <div className="p-4 bg-green-50 rounded-xl">
                            <h3 className="font-bold text-green-800 mb-1">🐧 Suica / PASMO</h3>
                            <p className="text-sm text-green-600">西瓜卡 (IC 卡)</p>
                            <p className="text-xs text-green-500 mt-1">可搭乘地鐵、JR、巴士，亦可超商付款。若持有 iPhone 可直接綁定 Apple Pay。</p>
                        </div>
                        <div className="p-4 bg-gray-50 rounded-xl">
                            <h3 className="font-bold text-gray-800 mb-1">🚇 東京地鐵乘車券 (TST)</h3>
                            <p className="text-sm text-gray-600">Tokyo Subway Ticket</p>
                            <p className="text-xs text-gray-500 mt-1">針對外國遊客的 24/48/72 小時券，無限搭乘東京地鐵與都營地鐵。</p>
                        </div>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};
