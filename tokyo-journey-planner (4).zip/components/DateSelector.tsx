import React, { useRef, useEffect } from 'react';
import { DayItinerary } from '../types';

interface DateSelectorProps {
  days: DayItinerary[];
  currentIndex: number;
  onSelect: (index: number) => void;
}

export const DateSelector: React.FC<DateSelectorProps> = ({ days, currentIndex, onSelect }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<(HTMLButtonElement | null)[]>([]);

  useEffect(() => {
    if (itemRefs.current[currentIndex] && scrollRef.current) {
        // Simple scroll into view logic for horizontal list
        const selectedElement = itemRefs.current[currentIndex];
        const container = scrollRef.current;
        
        if (selectedElement) {
            const containerWidth = container.offsetWidth;
            const elementLeft = selectedElement.offsetLeft;
            const elementWidth = selectedElement.offsetWidth;
            
            // Center the selected item
            const scrollPos = elementLeft - (containerWidth / 2) + (elementWidth / 2);
            
            container.scrollTo({
                left: scrollPos,
                behavior: 'smooth'
            });
        }
    }
  }, [currentIndex]);

  return (
    <div 
        ref={scrollRef}
        className="flex overflow-x-auto whitespace-nowrap px-4 pb-2 no-scrollbar"
    >
      {days.map((day, index) => {
        const isActive = index === currentIndex;
        return (
          <button
            key={day.date}
            ref={el => { itemRefs.current[index] = el; }}
            onClick={() => onSelect(index)}
            className={`
              flex flex-col items-center justify-center
              px-4 py-2 mr-2 min-w-[70px] rounded-xl transition-all duration-300
              ${isActive ? 'bg-white shadow-md scale-105' : 'bg-transparent opacity-60 hover:opacity-100'}
            `}
          >
            <span className={`text-[10px] font-bold uppercase tracking-wider ${isActive ? 'text-blue-500' : 'text-gray-500'}`}>
              {day.day}
            </span>
            <span className={`text-xl font-black ${isActive ? 'text-gray-800' : 'text-gray-500'}`}>
              {day.date.split('/')[1]}
            </span>
          </button>
        );
      })}
      {/* Spacer for end of list */}
      <div className="w-4 shrink-0" />
    </div>
  );
};