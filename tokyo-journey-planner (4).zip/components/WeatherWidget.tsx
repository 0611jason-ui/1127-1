import React, { useEffect, useState } from 'react';
import { CloudSun, Loader2, Thermometer, Droplets, Wind } from 'lucide-react';

interface WeatherData {
  current: {
    temperature_2m: number;
    weather_code: number;
    relative_humidity_2m: number;
    wind_speed_10m: number;
  };
  daily: {
    temperature_2m_max: number[];
    temperature_2m_min: number[];
  };
}

// WMO Weather interpretation codes (WW)
const getWeatherDescription = (code: number): string => {
  if (code === 0) return '晴朗';
  if (code >= 1 && code <= 3) return '多雲';
  if (code >= 45 && code <= 48) return '有霧';
  if (code >= 51 && code <= 55) return '毛毛雨';
  if (code >= 61 && code <= 65) return '下雨';
  if (code >= 71 && code <= 77) return '降雪';
  if (code >= 80 && code <= 82) return '陣雨';
  if (code >= 95) return '雷雨';
  return '陰天';
};

interface WeatherWidgetProps {
  className?: string;
  compact?: boolean;
}

export const WeatherWidget: React.FC<WeatherWidgetProps> = ({ className = "", compact = false }) => {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const response = await fetch(
          'https://api.open-meteo.com/v1/forecast?latitude=35.6895&longitude=139.6917&current=temperature_2m,weather_code,relative_humidity_2m,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min&timezone=Asia%2FTokyo'
        );
        const data = await response.json();
        setWeather(data);
      } catch (error) {
        console.error("Failed to fetch weather", error);
      } finally {
        setLoading(false);
      }
    };

    fetchWeather();
  }, []);

  if (loading) {
    return (
      <div className={`flex items-center justify-center p-4 bg-blue-50/50 rounded-2xl ${className}`}>
        <Loader2 size={20} className="animate-spin text-blue-400 mr-2" />
        <span className="text-sm text-gray-500">更新氣象...</span>
      </div>
    );
  }

  if (!weather) return null;

  return (
    <div className={`bg-gradient-to-br from-[#e0f2fe] to-white rounded-2xl shadow-sm border border-blue-100 p-5 ${className}`}>
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center">
            <CloudSun className="text-orange-400 mr-2" size={20} />
            <h3 className="font-bold text-gray-700">東京目前天氣</h3>
        </div>
        <span className="text-[10px] font-bold bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">LIVE</span>
      </div>

      <div className="flex justify-between items-end">
        <div>
          <div className="flex items-baseline space-x-2">
            <span className="text-4xl font-black text-gray-800 tracking-tighter">
                {Math.round(weather.current.temperature_2m)}°
            </span>
            <span className="text-lg font-bold text-gray-600">
                {getWeatherDescription(weather.current.weather_code)}
            </span>
          </div>
          
          <div className="flex space-x-3 mt-2 text-xs text-gray-500 font-medium">
             <span className="flex items-center">
                <Thermometer size={12} className="mr-1 text-red-400" />
                H: {Math.round(weather.daily.temperature_2m_max[0])}°
             </span>
             <span className="flex items-center">
                <Thermometer size={12} className="mr-1 text-blue-400" />
                L: {Math.round(weather.daily.temperature_2m_min[0])}°
             </span>
          </div>
        </div>

        {!compact && (
             <div className="text-right space-y-1">
                <div className="flex items-center justify-end text-xs text-gray-500">
                    <Droplets size={12} className="mr-1 text-blue-400" />
                    {weather.current.relative_humidity_2m}% 濕度
                </div>
                <div className="flex items-center justify-end text-xs text-gray-500">
                    <Wind size={12} className="mr-1 text-gray-400" />
                    {weather.current.wind_speed_10m} km/h
                </div>
            </div>
        )}
      </div>
    </div>
  );
};