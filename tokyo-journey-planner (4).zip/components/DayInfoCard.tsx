import React from 'react';
import { DayItinerary } from '../types';
import { MapPin, Building, Info } from 'lucide-react';

interface DayInfoCardProps {
  dayData: DayItinerary;
  dayIndex: number;
}

export const DayInfoCard: React.FC<DayInfoCardProps> = ({ dayData, dayIndex }) => {
  const isUeno = dayIndex < 3;
  const accommodationName = isUeno ? 'PAUL HOUSE' : '東京灣東方飯店';
  const accommodationMapUrl = isUeno 
    ? 'https://maps.app.goo.gl/ddYgRKjFU8inJGNM7' 
    : 'https://maps.app.goo.gl/RWetgQnS3B2i7MXg9';

  return (
    <div className="space-y-4">
        {/* Title Card */}
        <div className="p-5 bg-white rounded-2xl shadow-sm border border-gray-100">
            <h2 className="text-2xl font-black text-gray-800 leading-tight">
                {dayData.title}
            </h2>
            <div className="flex items-center mt-2 text-sm text-gray-500">
                <MapPin size={14} className="mr-1 text-blue-500" />
                {dayData.city}
            </div>
        </div>

        <div className="grid grid-cols-1 gap-4">
            {/* Accommodation Widget */}
            <div className="p-4 bg-white rounded-2xl shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                        <Building size={18} className="text-indigo-500 mr-2" />
                        <h3 className="text-sm font-bold text-gray-700">住宿</h3>
                    </div>
                </div>
                <a 
                    href={accommodationMapUrl} 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between group p-2 -mx-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                    <span className="text-xl font-bold text-gray-800 group-hover:text-blue-600 transition-colors">
                        {accommodationName}
                    </span>
                    <Info size={16} className="text-gray-300 group-hover:text-blue-500" />
                </a>
            </div>
        </div>
    </div>
  );
};