import React from 'react';
import { Stop } from '../types';

interface TimelineItemProps {
  stop: Stop;
  onClick: () => void;
  isLast: boolean;
}

export const TimelineItem: React.FC<TimelineItemProps> = ({ stop, onClick, isLast }) => {
  return (
    <div 
        className="relative pl-[96px] min-h-[70px] group cursor-pointer"
        onClick={onClick}
    >
        {/* Time - positioned absolutely to the left */}
        <div className="absolute left-0 top-0 w-[60px] text-right pr-2 pt-1">
            <span className="font-bold text-gray-800 text-xl leading-none block font-mono tracking-tight">
                {stop.time}
            </span>
        </div>

        {/* Vertical Line - Moved right to 70px */}
        {!isLast && (
            <div className="absolute left-[70px] top-3 bottom-[-16px] w-[2px] bg-gray-100 group-hover:bg-blue-100 transition-colors"></div>
        )}

        {/* Dot - Moved right to 70px */}
        <div className="absolute left-[70px] top-2 w-3 h-3 bg-white border-[3px] border-blue-500 rounded-full transform -translate-x-[5px] z-10 shadow-sm group-hover:scale-125 transition-transform duration-200"></div>

        {/* Content */}
        <div className="pb-8 pr-4 relative -top-1 transition-transform duration-200 group-active:scale-[0.99]">
            <div className="bg-white rounded-lg p-1 group-hover:bg-gray-50 transition-colors">
                <h4 className="text-xl font-bold text-gray-900 mb-2 leading-snug">
                    {stop.title}
                </h4>

                {/* Optional Image */}
                {stop.imageUrl && (
                    <div className="mb-2.5 overflow-hidden rounded-lg shadow-sm border border-gray-100">
                        <img 
                            src={stop.imageUrl} 
                            alt={stop.title} 
                            className="w-full h-36 object-cover transform transition-transform duration-500 group-hover:scale-105"
                        />
                    </div>
                )}

                <p className="text-base text-gray-500 leading-relaxed line-clamp-3">
                    {stop.details}
                </p>
                
                {stop.tags && stop.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                        {stop.tags.map(tag => (
                            <span key={tag} className="px-2 py-0.5 bg-blue-50 text-blue-600 text-xs font-medium rounded-md">
                                {tag}
                            </span>
                        ))}
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};