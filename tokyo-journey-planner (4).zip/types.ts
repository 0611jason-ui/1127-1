
export type StopType = 'FLIGHT' | 'ARRIVAL' | 'TRANSPORT' | 'ACCOMMODATION' | 'SIGHTSEEING' | 'FOOD' | 'SHOPPING';

export interface Stop {
  time: string;
  type: StopType;
  title: string;
  details: string;
  tags: string[];
  imageUrl?: string; // Optional image URL for attractions
  mapUrl?: string; // Optional Google Maps link
}

export interface DayItinerary {
  date: string;
  day: string;
  title: string;
  city: string;
  stops: Stop[];
}
