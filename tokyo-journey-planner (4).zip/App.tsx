import React, { useState } from 'react';
import { ITINERARY_DATA } from './constants';
import { Stop } from './types';
import { DateSelector } from './components/DateSelector';
import { DayInfoCard } from './components/DayInfoCard';
import { TimelineItem } from './components/TimelineItem';
import { DetailModal } from './components/DetailModal';
import { HomeView } from './components/HomeView';
import { ChevronLeft } from 'lucide-react';

type ViewState = 'home' | 'itinerary';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('home');
  const [currentDayIndex, setCurrentDayIndex] = useState(0);
  const [selectedStop, setSelectedStop] = useState<Stop | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const currentDay = ITINERARY_DATA[currentDayIndex];

  const handleStopClick = (stop: Stop) => {
    setSelectedStop(stop);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setTimeout(() => {
      setSelectedStop(null);
    }, 300); // Wait for animation
  };

  // Render Home View
  if (currentView === 'home') {
    return (
        <div className="min-h-screen bg-[#f0f0e8] flex justify-center">
            <div className="w-full max-w-[420px] bg-white min-h-screen shadow-2xl relative flex flex-col">
                <HomeView onNavigate={setCurrentView} />
                
                {/* Footer */}
                <footer className="p-4 text-center text-[10px] text-gray-400 border-t border-gray-100 bg-white pb-safe-bottom">
                    © 2026 Mobile Planner Mockup
                </footer>
            </div>
        </div>
    );
  }

  // Render Itinerary View
  return (
    <div className="min-h-screen bg-[#f0f0e8] flex justify-center">
      {/* Mobile Container Constraint */}
      <div className="w-full max-w-[420px] bg-white min-h-screen shadow-2xl relative flex flex-col">
        
        {/* Header Section */}
        <header className="bg-[#ebebd8] pt-safe-top pb-2 sticky top-0 z-20 shadow-sm">
            {/* Top Bar with Back Button */}
            <div className="px-4 pt-4 flex justify-between items-center mb-2">
                <button 
                    onClick={() => setCurrentView('home')}
                    className="flex items-center px-2 py-1 -ml-2 text-gray-600 hover:text-gray-900 transition-colors bg-white/50 rounded-lg backdrop-blur-sm"
                >
                    <ChevronLeft size={20} />
                    <span className="text-xs font-bold ml-1">首頁</span>
                </button>
                <span className="font-medium text-xs text-gray-500 tracking-widest uppercase">Itinerary</span>
                <span className="font-semibold text-gray-800 text-xs bg-blue-100 px-2 py-1 rounded-full">Day {currentDayIndex + 1}</span>
            </div>

            <div className="px-4 mb-4">
                <h1 className="text-2xl font-black text-gray-800 tracking-tight">行程細節</h1>
            </div>

            {/* Date Selector */}
            <DateSelector 
                days={ITINERARY_DATA} 
                currentIndex={currentDayIndex} 
                onSelect={setCurrentDayIndex} 
            />
        </header>

        {/* Main Content Scrollable Area */}
        <main className="flex-1 overflow-y-auto bg-white">
            <div className="p-4 space-y-6 pb-24">
                {/* Day Overview Card */}
                <DayInfoCard dayData={currentDay} dayIndex={currentDayIndex} />

                {/* Timeline */}
                <div className="bg-white rounded-xl">
                     <h3 className="text-lg font-bold text-gray-800 mb-6 pl-2 border-l-4 border-blue-500">
                        本日行程時序
                     </h3>
                     <div className="relative">
                        {currentDay.stops.map((stop, index) => (
                            <TimelineItem 
                                key={`${currentDay.date}-${index}`} 
                                stop={stop} 
                                onClick={() => handleStopClick(stop)}
                                isLast={index === currentDay.stops.length - 1}
                            />
                        ))}
                     </div>
                </div>
            </div>
        </main>

        {/* Footer */}
        <footer className="p-4 text-center text-[10px] text-gray-400 border-t border-gray-100 bg-white pb-safe-bottom">
            © 2026 Mobile Planner Mockup
        </footer>

        {/* Modal */}
        <DetailModal 
            isOpen={isModalOpen} 
            onClose={closeModal} 
            stop={selectedStop} 
        />
        
      </div>
    </div>
  );
};

export default App;