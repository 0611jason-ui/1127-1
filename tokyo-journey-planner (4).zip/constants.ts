
import { DayItinerary } from './types';

export const ITINERARY_DATA: DayItinerary[] = [
    {
        date: "1/11", day: "Day 1", title: "抵達與澀谷潮流初探", city: "東京 (上野/澀谷)",
        stops: [
            { time: "02:25", type: "FLIGHT", title: "出發 (MM620)", details: "搭乘樂桃航空 MM620 班機 (桃機T1 \u2192 成田T1)，直飛東京。", tags: ["機場", "交通"] },
            { time: "06:30", type: "ARRIVAL", title: "抵達東京成田機場 (NRT)", details: "抵達第一航廈辦理入境手續，準備搭乘交通工具進市區。", tags: ["機場", "早晨"] },
            { time: "07:30", type: "TRANSPORT", title: "京成 Skyliner \u2192 上野", details: "搭乘 Skyliner (或京成本線) 前往京成上野站，車程約 45 分鐘。", tags: ["交通", "快速"] },
            { 
                time: "09:00", 
                type: "ACCOMMODATION", 
                title: "上野飯店寄放行李", 
                details: "抵達上野的飯店，先寄放行李。", 
                tags: ["住宿", "休息"],
                mapUrl: "https://maps.app.goo.gl/ddYgRKjFU8inJGNM7"
            },
            { 
                time: "10:30", 
                type: "SIGHTSEEING", 
                title: "澀谷、原宿、表參道", 
                details: "探索東京最時尚的街區，感受潮流文化，並找地方享用早午餐。", 
                tags: ["購物", "潮流"],
                imageUrl: "https://images.unsplash.com/photo-1542051841857-5f90071e7989?q=80&w=800&auto=format&fit=crop"
            },
            { 
                time: "14:30", 
                type: "SIGHTSEEING", 
                title: "SHIBUYA SKY", 
                details: "在 230 公尺高空欣賞著名的澀谷交叉路口和東京景觀。", 
                tags: ["觀光"],
                imageUrl: "https://images.unsplash.com/photo-1675240862200-5420f7c92945?q=80&w=800&auto=format&fit=crop"
            },
            { 
                time: "17:30", 
                type: "FOOD", 
                title: "晚餐：池袋拉麵", 
                details: "前往池袋尋找一蘭或無敵家拉麵店，或選擇其他特色餐廳。", 
                tags: ["美食", "晚餐"],
                imageUrl: "https://images.unsplash.com/photo-1569925238260-1554045863d6?q=80&w=800&auto=format&fit=crop"
            }
        ]
    },
    {
        date: "1/12", day: "Day 2", title: "築地海鮮與鎌倉古都巡禮", city: "築地/鎌倉",
        stops: [
            { 
                time: "08:00", 
                type: "FOOD", 
                title: "築地場外市場 (早餐)", 
                details: "品嚐新鮮的壽司、玉子燒等海鮮早餐。", 
                tags: ["美食", "市場"],
                imageUrl: "https://images.unsplash.com/photo-1629864272186-b484803d3c7c?q=80&w=800&auto=format&fit=crop"
            },
            { time: "10:00", type: "TRANSPORT", title: "前往鎌倉 (JR)", details: "搭乘 JR 前往鎌倉。", tags: ["交通", "電車"] },
            { 
                time: "12:00", 
                type: "SIGHTSEEING", 
                title: "鎌倉大佛 (高德院)", 
                details: "參觀莊嚴的青銅大佛。", 
                tags: ["歷史", "寺廟"],
                imageUrl: "https://images.unsplash.com/photo-1585816995420-53e346f0490b?q=80&w=800&auto=format&fit=crop"
            },
            { 
                time: "14:00", 
                type: "SIGHTSEEING", 
                title: "鶴岡八幡宮", 
                details: "古都的重要神社，感受日式古建築。", 
                tags: ["神社", "文化"],
                imageUrl: "https://images.unsplash.com/photo-1599553530378-01389c927c3f?q=80&w=800&auto=format&fit=crop"
            },
            { 
                time: "16:00", 
                type: "SIGHTSEEING", 
                title: "鎌倉高校前 (灌籃高手)", 
                details: "經典的平交道海景，拍照留念。", 
                tags: ["動漫", "拍照"],
                imageUrl: "https://images.unsplash.com/photo-1624683053531-509805908f56?q=80&w=800&auto=format&fit=crop"
            },
            { time: "19:30", type: "FOOD", title: "晚餐：上野居酒屋", details: "返回上野，在附近的居酒屋用餐。", tags: ["美食", "居酒屋"] }
        ]
    },
    {
        date: "1/13", day: "Day 3", title: "御殿場購物與阿美橫町美食", city: "御殿場/上野",
        stops: [
            { time: "09:00", type: "TRANSPORT", title: "巴士 \u2192 御殿場", details: "搭乘直達巴士前往御殿場。", tags: ["交通", "購物"] },
            { 
                time: "11:00", 
                type: "SHOPPING", 
                title: "御殿場 Premium Outlet", 
                details: "全日購物，遠眺富士山。", 
                tags: ["購物", "富士山"],
                imageUrl: "https://images.unsplash.com/photo-1490806843957-31f4c9a91c65?q=80&w=800&auto=format&fit=crop"
            },
            { time: "18:00", type: "TRANSPORT", title: "返回上野", details: "搭乘巴士返回上野。", tags: ["交通"] },
            { 
                time: "20:00", 
                type: "FOOD", 
                title: "阿美橫丁", 
                details: "在阿美橫丁享受熱鬧的市場晚餐。", 
                tags: ["美食", "平價"],
                imageUrl: "https://images.unsplash.com/photo-1582449089066-5b0c95a0d4c8?q=80&w=800&auto=format&fit=crop"
            }
        ]
    },
    {
        date: "1/14", day: "Day 4", title: "淺草文化與未來藝術光影", city: "淺草/台場",
        stops: [
            { 
                time: "09:00", 
                type: "SIGHTSEEING", 
                title: "淺草寺 (雷門)", 
                details: "參觀標誌性的雷門大燈籠和淺草寺。", 
                tags: ["文化", "觀光"],
                imageUrl: "https://images.unsplash.com/photo-1536098561742-ca998e48cbcc?q=80&w=800&auto=format&fit=crop"
            },
            { 
                time: "11:00", 
                type: "SIGHTSEEING", 
                title: "晴空塔 (Skytree)", 
                details: "在東京新地標欣賞全景。", 
                tags: ["高塔", "觀景"],
                imageUrl: "https://images.unsplash.com/photo-1579294247271-9650b077a28e?q=80&w=800&auto=format&fit=crop"
            },
            { 
                time: "13:00", 
                type: "FOOD", 
                title: "午餐：敘敘苑燒肉", 
                details: "享受高品質的敘敘苑午間套餐。", 
                tags: ["美食", "燒肉"],
                imageUrl: "https://images.unsplash.com/photo-1552611052-33e04de081de?q=80&w=800&auto=format&fit=crop"
            },
            { time: "15:00", type: "ACCOMMODATION", title: "移住宿 \u2192 東京灣東方飯店", details: "移動至台場附近的東方飯店辦理入住。", tags: ["住宿", "交通"] },
            { 
                time: "17:30", 
                type: "SIGHTSEEING", 
                title: "teamLab Planets TOKYO DMM", 
                details: "沉浸式數位藝術體驗，建議穿短褲。", 
                tags: ["藝術", "互動"],
                imageUrl: "https://images.unsplash.com/photo-1570530962637-97594d2d6d03?q=80&w=800&auto=format&fit=crop"
            },
            { time: "20:00", type: "FOOD", title: "晚餐：台場", details: "在台場購物中心享用晚餐。", tags: ["美食", "晚餐"] }
        ]
    },
    {
        date: "1/15", day: "Day 5", title: "迪士尼海洋樂園夢幻一日", city: "東京迪士尼海洋",
        stops: [
            { 
                time: "08:30", 
                type: "SIGHTSEEING", 
                title: "迪士尼海洋樂園", 
                details: "全日享受東京迪士尼海洋的夢幻與刺激。", 
                tags: ["樂園", "娛樂"],
                imageUrl: "https://images.unsplash.com/photo-1524312672583-16279f06df14?q=80&w=800&auto=format&fit=crop"
            },
            { 
                time: "20:30", 
                type: "SIGHTSEEING", 
                title: "觀賞夜間表演", 
                details: "在樂園內觀賞精彩的夜間水上表演。", 
                tags: ["表演", "煙火"],
                imageUrl: "https://images.unsplash.com/photo-1534065639178-011d619a9301?q=80&w=800&auto=format&fit=crop"
            },
            { time: "21:30", type: "TRANSPORT", title: "返回東方飯店", details: "搭乘接駁或電車返回飯店。", tags: ["交通", "休息"] }
        ]
    },
    {
        date: "1/16", day: "Day 6", title: "臨別購物與溫馨返家", city: "成田/桃園",
        stops: [
            { time: "09:00", type: "SHOPPING", title: "Aeon Mall (最終採買)", details: "在附近的 Aeon Mall 購買最終伴手禮。", tags: ["購物", "伴手禮"] },
            { time: "12:00", type: "FOOD", title: "午餐", details: "在 Aeon Mall 解決午餐。", tags: ["美食"] },
            { time: "14:00", type: "TRANSPORT", title: "前往成田機場", details: "搭乘巴士或電車前往成田機場。", tags: ["交通", "機場"] },
            { time: "19:00", type: "FLIGHT", title: "成田 (NRT) \u2192 桃園 (TPE)", details: "搭乘台灣虎航 IT203 (成田T2 \u2192 桃機T1)，返回溫暖的家。", tags: ["機場", "返家"] }
        ]
    }
];
